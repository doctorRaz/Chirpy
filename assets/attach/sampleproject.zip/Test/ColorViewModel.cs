﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Media;

using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;

namespace MyNamespace
{
    public class AcadColors : ObservableCollection<AcadColor>
    {
        public AcadColors()
            : base()
        {
            Add(new AcadColor("ByLayer", 255, 255, 255));
            Add(new AcadColor("ByBlock", 255, 255, 255));
            Add(new AcadColor("Red", 255, 0, 0));
            Add(new AcadColor("Yellow", 255, 255, 0));
            Add(new AcadColor("Green", 0, 255, 0));
            Add(new AcadColor("Cyan", 0, 255, 255));
            Add(new AcadColor("Blue", 0, 0, 255));
            Add(new AcadColor("Magenta", 255, 0, 255));
            Add(new AcadColor("White", 255, 255, 255));
            Add(new AcadColor("Select Colors...", 255, 255, 255));
        }

        public bool Contains(String name)
        {
            for(int i = 0; i < Count; i++)
            {
                if(this[i].Name.Equals(name))
                    return true;
            }
            return false;
        }
    }

    public class AcadColor : System.Object
    {
        public String Name
        {
            get;
            set;
        }

        public System.Windows.Media.SolidColorBrush ColorBrush
        {
            get
            {
                SolidColorBrush brush = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                return brush;  
            }
        }

        public byte Red
        {
            get;
            set;
        }

        public byte Green
        {
            get;
            set;
        }

        public byte Blue
        {
            get;
            set;
        }

        public String IsVisible
        {
            get
            {
                if(Name.Contains("Select"))
                    return "Collapsed";
                return "Visible";
            }
        }

        public AcadColor(String name, byte R, byte G, byte B)
        {
            Name = name;
            Red = R;
            Green = G;
            Blue = B;
        }

        public AcadColor()
        {
            Name = String.Empty;
            Red = 255;
            Green = 255;
            Blue = 255;
        }

        public override bool Equals(System.Object obj)
        {
            // If parameter is null return false:
            if ((object)obj == null)
            {
                return false;
            }
            AcadColor color = obj as AcadColor;
            if (color != null)
            {
                // Return true if the fields match:
                return (color.Name == Name);
            }
            return false;
        }
    }

    public class ColorViewModel : INotifyPropertyChanged
    {
        AcadColors _myAcadColors = new AcadColors();
        bool _showingColorDlg = false;

        public ColorViewModel()
        {
        }

        public AcadColors MyAcadColors
        {
            get
            {
                return _myAcadColors;
            }
        }

        private string _colorString = "Red";
        
        public string ColorString
        {
            get 
            { 
                return _colorString; 
            }

            set
            {
                if (value != null && _colorString != value)
                {
                    String colorName = value;
                    if (! _showingColorDlg && value.Contains("Select"))
                    {
                        _showingColorDlg = true;
                        colorName = ShowColorDlg();
                    }
                    _showingColorDlg = false;

                    _colorString = colorName;
                    NotifyPropertyChanged("ColorString");
                }
            }
        }

        #region INotifyPropertyChanged Members

        /// <summary>
        /// Need to implement this interface in order to get data binding
        /// to work properly.
        /// </summary>
        /// <param name="propertyName"></param>
        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        public String ShowColorDlg()
        {
            Document  doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;

            Autodesk.AutoCAD.Windows.ColorDialog dlg = new Autodesk.AutoCAD.Windows.ColorDialog();
            if (dlg.ShowDialog() !=  System.Windows.Forms.DialogResult.OK)
            {
                return String.Empty;
            }

            Autodesk.AutoCAD.Colors.Color clr = dlg.Color;
            if (! clr.IsByAci)
            {
                if (clr.IsByLayer)
                {
                    return "ByLayer";
                }
                else if (clr.IsByBlock)
                {
                    return "ByBlock";
                }
                else
                {
                    String colorName = String.Format("{0},{1},{2}", clr.Red, clr.Green, clr.Blue);

                    if(_myAcadColors.Contains(colorName) == false)
                        _myAcadColors.Insert(_myAcadColors.Count - 1, new AcadColor(colorName, clr.Red, clr.Green, clr.Blue));
                    
                    return colorName;
                }
            }
            else
            {
                short colIndex = clr.ColorIndex;

                System.Byte byt = System.Convert.ToByte(colIndex);
                int rgb = Autodesk.AutoCAD.Colors.EntityColor.LookUpRgb(byt);
                long b = (rgb & 0xffL);
                long g = (rgb & 0xff00L) >> 8;
                long r = rgb >> 16;

                String colorName = String.Format("Color {0}", colIndex);

                if (_myAcadColors.Contains(colorName) == false)
                    _myAcadColors.Insert(_myAcadColors.Count - 1, new AcadColor(colorName, (byte)r, (byte)g, (byte)b));
                
                return colorName;
            }
        }

        public void Reload()
        {
            _myAcadColors = new AcadColors();
            NotifyPropertyChanged("MyAcadColors");
        }
    }
}