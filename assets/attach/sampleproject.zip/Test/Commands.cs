﻿using System;
using System.Reflection;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Drawing;
using System.ComponentModel;

using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Windows;

[assembly: CommandClass(typeof(MyNamespace.ExtApp))]

namespace MyNamespace
{
    public class ExtApp : IExtensionApplication
    {
        private static PaletteSet _ps = null;

        [CommandMethod("Test", CommandFlags.Session)]
        public void TestMethod()
        {
            if(_ps == null)
            {
                _ps = new PaletteSet("WPF Palette");
                _ps.Size = new Size(400, 600);
                _ps.DockEnabled = (DockSides)((int)DockSides.Left + (int)DockSides.Right);
            
                MyWPFUserControl uc = new MyWPFUserControl();
                _ps.AddVisual("Test", uc);
            }

            _ps.KeepFocus = true;
            _ps.Visible = true;
        }

       void IExtensionApplication.Initialize(){}

        void IExtensionApplication.Terminate(){}
    }
}
