﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Media;

using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;

namespace MyNamespace
{
    public class AcadLayers : ObservableCollection<AcadLayer>
    {
        public AcadLayers()
            : base()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            Database db = doc.Database;
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                
                foreach(ObjectId ltrId in lt)
                {
                    LayerTableRecord ltr = tr.GetObject(ltrId, OpenMode.ForRead) as LayerTableRecord;
                    Autodesk.AutoCAD.Colors.Color clr = ltr.Color;

                    if (!clr.IsByAci)
                    {
                        if (clr.IsByLayer)
                        {
                            Add(new AcadLayer(ltr.Name, (byte)255, (byte)255, (byte)255, !ltr.IsOff, ltr.IsFrozen, ltr.IsLocked));
                        }
                        else if (clr.IsByBlock)
                        {
                            Add(new AcadLayer(ltr.Name, (byte)255, (byte)255, (byte)255, !ltr.IsOff, ltr.IsFrozen, ltr.IsLocked));
                        }
                        else
                        {
                            Add(new AcadLayer(ltr.Name, clr.Red, clr.Green, clr.Blue, !ltr.IsOff, ltr.IsFrozen, ltr.IsLocked));
                        }
                    }
                    else
                    {
                        short colIndex = clr.ColorIndex;

                        System.Byte byt = System.Convert.ToByte(colIndex);
                        int rgb = Autodesk.AutoCAD.Colors.EntityColor.LookUpRgb(byt);
                        long b = (rgb & 0xffL);
                        long g = (rgb & 0xff00L) >> 8;
                        long r = rgb >> 16;

                        if (colIndex == 7)
                        {
                            if (r <= 128 && g <= 128 && b <= 128)
                            {// White
                                Add(new AcadLayer(ltr.Name, 255, 255, 255, !ltr.IsOff, ltr.IsFrozen, ltr.IsLocked));
                            }
                            else
                            {// Black
                                Add(new AcadLayer(ltr.Name, 0, 0, 0, !ltr.IsOff, ltr.IsFrozen, ltr.IsLocked));
                            }
                        }
                        else
                        {
                            Add(new AcadLayer(ltr.Name, (byte)r, (byte)g, (byte)b, !ltr.IsOff, ltr.IsFrozen, ltr.IsLocked));
                        }
                    }
                }
                tr.Commit();
            }
        }
    }

    public class AcadLayer
    {
        public String LayerName
        {
            get;
            set;
        }

        public System.Windows.Media.SolidColorBrush LayerColorBrush
        {
            get
            {
                SolidColorBrush brush = new SolidColorBrush(Color.FromRgb(Red, Green, Blue));
                return brush;
            }
        }

        public byte Red
        {
            get;
            set;
        }

        public byte Green
        {
            get;
            set;
        }

        public byte Blue
        {
            get;
            set;
        }

        bool _isOn;
        bool _isFrozen;
        bool _isLocked;

        public String IsOn
        {
            get
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    LayerTableRecord ltr = tr.GetObject(lt[LayerName], OpenMode.ForRead) as LayerTableRecord;
                    _isOn = ! ltr.IsOff;
                    tr.Commit();
                }

                if(_isOn)
                    return "Visible";

                return "Collapsed";
            }
        }

        public String IsOff
        {
            get
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    LayerTableRecord ltr = tr.GetObject(lt[LayerName], OpenMode.ForRead) as LayerTableRecord;
                    _isOn = !ltr.IsOff;
                    tr.Commit();
                }

                if (! _isOn)
                    return "Visible";

                return "Collapsed";
            }
        }

        public String IsFrozen
        {
            get
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    LayerTableRecord ltr = tr.GetObject(lt[LayerName], OpenMode.ForRead) as LayerTableRecord;
                    _isFrozen = ltr.IsFrozen;
                    tr.Commit();
                }

                if(_isFrozen)
                    return "Visible";
             
                return "Collapsed";
            }
        }

        public String IsThawed
        {
            get
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    LayerTableRecord ltr = tr.GetObject(lt[LayerName], OpenMode.ForRead) as LayerTableRecord;
                    _isFrozen = ltr.IsFrozen;
                    tr.Commit();
                }

                if (! _isFrozen)
                    return "Visible";

                return "Collapsed";
            }
        }

        public String IsLocked
        {
            get
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    LayerTableRecord ltr = tr.GetObject(lt[LayerName], OpenMode.ForRead) as LayerTableRecord;
                    _isLocked = ltr.IsLocked;
                    tr.Commit();
                }

                if (_isLocked)
                    return "Visible";

                return "Collapsed";
            }
        }

        public String IsUnLocked
        {
            get
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                Editor ed = doc.Editor;
                Database db = doc.Database;
                using (Transaction tr = db.TransactionManager.StartTransaction())
                {
                    LayerTable lt = tr.GetObject(db.LayerTableId, OpenMode.ForRead) as LayerTable;
                    LayerTableRecord ltr = tr.GetObject(lt[LayerName], OpenMode.ForRead) as LayerTableRecord;
                    _isLocked = ltr.IsLocked;
                    tr.Commit();
                }

                if (! _isLocked)
                    return "Visible";

                return "Collapsed";
            }
        }

        public AcadLayer(String layerName, byte R, byte G, byte B, bool isOn, bool isFrozen, bool isLocked)
        {
            LayerName = layerName;
            Red = R;
            Green = G;
            Blue = B;

            _isOn = isOn;
            _isFrozen = isFrozen;
            _isLocked = isLocked;
        }

        public AcadLayer()
        {
            LayerName = "0";
            Red = 255;
            Green = 255;
            Blue = 255;

            _isOn = true;
            _isFrozen = false;
            _isLocked = false;
        }

        public override bool Equals(System.Object obj)
        {
            // If parameter is null return false:
            if ((object)obj == null)
            {
                return false;
            }
            AcadLayer layer = obj as AcadLayer;
            if (layer != null)
            {
                // Return true if the fields match:
                return (layer.LayerName == LayerName);
            }
            return false;
        }
    }

    /// <summary>
    /// Class used to bind the combobox selections to. Must implement 
    /// INotifyPropertyChanged in order to get the data binding to 
    /// work correctly.
    /// </summary>
    public class LayerViewModel : INotifyPropertyChanged
    {
        AcadLayers _myAcadLayers = new AcadLayers();

        public LayerViewModel()
        {
        }

        public AcadLayers MyAcadLayers
        {
            get
            {
                return _myAcadLayers;
            }
        }

        private string _layerString = "0";
        /// <summary>
        /// String property used in binding examples.
        /// </summary>
        public string LayerString
        {
            get { return _layerString; }
            set
            {
                if (value != null && _layerString != value)
                {
                    _layerString = value;
                    NotifyPropertyChanged("LayerString");
                }
            }
        }

        #region INotifyPropertyChanged Members

        /// <summary>
        /// Need to implement this interface in order to get data binding
        /// to work properly.
        /// </summary>
        /// <param name="propertyName"></param>
        private void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        public void Reload()
        {
            _myAcadLayers = new AcadLayers();
            NotifyPropertyChanged("MyAcadLayers");
        }
    }
}
