﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.EditorInput;

namespace MyNamespace
{
    /// <summary>
    /// Interaction logic for MyWPFUserControl.xaml
    /// </summary>
    public partial class MyWPFUserControl : UserControl
    {
        private ColorViewModel clrViewModel = new ColorViewModel();
        private LayerViewModel layerViewModel = new LayerViewModel();

        public MyWPFUserControl()
        {
            DataContext = this;
            InitializeComponent();
        }

        public ColorViewModel ColorDataContext
        {
            get
            {
                return clrViewModel;
            }
        }

        public LayerViewModel LayerDataContext
        {
            get
            {
                return layerViewModel;
            }
        }

        private void ReloadControls_Click(object sender, RoutedEventArgs e)
        {
            clrViewModel.Reload();
            layerViewModel.Reload();
        }
    }
}
